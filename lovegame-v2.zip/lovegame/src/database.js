const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'lovegame.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    display_name TEXT NOT NULL,
    avatar TEXT DEFAULT '💜',
    level INTEGER DEFAULT 1,
    xp INTEGER DEFAULT 0,
    total_score INTEGER DEFAULT 0,
    wins INTEGER DEFAULT 0,
    games_played INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS badges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    badge_key TEXT,
    earned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS game_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_code TEXT,
    game_type TEXT,
    winner_id INTEGER,
    player1_id INTEGER,
    player2_id INTEGER,
    score1 INTEGER DEFAULT 0,
    score2 INTEGER DEFAULT 0,
    played_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS couple_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user1_id INTEGER,
    user2_id INTEGER,
    games_together INTEGER DEFAULT 0,
    wins_user1 INTEGER DEFAULT 0,
    wins_user2 INTEGER DEFAULT 0,
    last_played DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// ---- USER FUNCTIONS ----
function createUser(username, hashedPassword, displayName, avatar) {
  const stmt = db.prepare('INSERT INTO users (username, password, display_name, avatar) VALUES (?, ?, ?, ?)');
  return stmt.run(username, hashedPassword, displayName, avatar);
}

function getUserByUsername(username) {
  return db.prepare('SELECT * FROM users WHERE username = ?').get(username);
}

function getUserById(id) {
  return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
}

function addXP(userId, xpAmount) {
  const user = getUserById(userId);
  if (!user) return;
  const newXp = user.xp + xpAmount;
  const newLevel = Math.floor(newXp / 500) + 1;
  const newTotal = user.total_score + xpAmount;
  db.prepare('UPDATE users SET xp = ?, level = ?, total_score = ? WHERE id = ?')
    .run(newXp, newLevel, newTotal, userId);
  return { newXp, newLevel, levelUp: newLevel > user.level };
}

function addWin(userId) {
  db.prepare('UPDATE users SET wins = wins + 1, games_played = games_played + 1 WHERE id = ?').run(userId);
}

function addGamePlayed(userId) {
  db.prepare('UPDATE users SET games_played = games_played + 1 WHERE id = ?').run(userId);
}

// ---- BADGE FUNCTIONS ----
const BADGES = {
  first_win:    { key: 'first_win',    name: 'الفوز الأول',     icon: '🏆', desc: 'فزت لأول مرة' },
  quiz_master:  { key: 'quiz_master',  name: 'ملك الأسئلة',    icon: '🧠', desc: 'فزت 5 جولات اختبار' },
  artist:       { key: 'artist',       name: 'الفنان',          icon: '🎨', desc: 'فزت في لعبة الرسم' },
  truth_darer:  { key: 'truth_darer',  name: 'الجريء',          icon: '🔥', desc: 'لعبت حقيقة أو جرأة' },
  uno_champ:    { key: 'uno_champ',    name: 'بطل UNO',         icon: '🃏', desc: 'فزت في UNO' },
  millionaire:  { key: 'millionaire',  name: 'المليونير',       icon: '💰', desc: 'وصلت السؤال النهائي' },
  streak_3:     { key: 'streak_3',     name: 'ثلاثية',          icon: '⚡', desc: 'فزت 3 مرات متتالية' },
  lovebird:     { key: 'lovebird',     name: 'عصفور الحب',      icon: '💕', desc: 'لعبتم 10 جولات سوا' },
};

function awardBadge(userId, badgeKey) {
  const existing = db.prepare('SELECT id FROM badges WHERE user_id = ? AND badge_key = ?').get(userId, badgeKey);
  if (existing) return false;
  db.prepare('INSERT INTO badges (user_id, badge_key) VALUES (?, ?)').run(userId, badgeKey);
  return true;
}

function getUserBadges(userId) {
  const rows = db.prepare('SELECT badge_key FROM badges WHERE user_id = ?').all(userId);
  return rows.map(r => BADGES[r.badge_key]).filter(Boolean);
}

function checkAndAwardBadges(userId) {
  const user = getUserById(userId);
  if (!user) return [];
  const newBadges = [];
  if (user.wins >= 1 && awardBadge(userId, 'first_win')) newBadges.push(BADGES.first_win);
  if (user.wins >= 3 && awardBadge(userId, 'streak_3')) newBadges.push(BADGES.streak_3);
  if (user.games_played >= 10 && awardBadge(userId, 'lovebird')) newBadges.push(BADGES.lovebird);
  return newBadges;
}

// ---- GAME HISTORY ----
function saveGameResult(roomCode, gameType, winnerId, p1Id, p2Id, s1, s2) {
  db.prepare('INSERT INTO game_history (room_code, game_type, winner_id, player1_id, player2_id, score1, score2) VALUES (?,?,?,?,?,?,?)')
    .run(roomCode, gameType, winnerId, p1Id, p2Id, s1, s2);
}

module.exports = {
  db, createUser, getUserByUsername, getUserById,
  addXP, addWin, addGamePlayed,
  awardBadge, getUserBadges, checkAndAwardBadges, BADGES,
  saveGameResult,
};
